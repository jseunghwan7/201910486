const userData = {
    '제우스': {
        level: 625,
        tier: 'Master 350LP',
        winRate: '67%',
        tierImage: 'images/master.png',
        faceImage: 'images/zeus.png'
    },
    '오너': {
        level: 518,
        tier: 'Master 496LP',
        winRate: '71%',
        tierImage: 'images/master.png',
        faceImage: 'images/oner.png'
    },
    '페이커': {
        level: 758,
        tier: 'Master 143LP',
        winRate: '74%',
        tierImage: 'images/master.png',
        faceImage: 'images/faker.png'
    },
    '구마유시': {
        level: 704,
        tier: 'Grandmaster 649LP',
        winRate: '68%',
        tierImage: 'images/grandmaster.png',
        faceImage: 'images/guma.png'
    },
    '캐리아': {
        level: 867,
        tier: 'Master 316LP',
        winRate: '70%',
        tierImage: 'images/master.png',
        faceImage: 'images/keria.png'
    }
};



const championsData = {
    탑: [
        { 
            name: '가렌', 
            image: 'images/garen.png',
            tier: '2티어',
            winRate: '51.37%',
            pickRate: '3.18%',
            banRate: '1.02%',
            summonerSpells: [
                'images/garenspell.png'
            ],
            items: [
                'images/garenitem.png'
            ]
        },
        { 
            name: '다리우스', 
            image: 'images/darius.png',
            tier: '1티어',
            winRate: '51.03%',
            pickRate: '5.75%',
            banRate: '15.52%',
            summonerSpells: [
                'images/dariusspell.png'
            ],
            items: [
                'images/dariusitem.png'
            ]
        }
    ],
    정글: [
        { 
            name: '리 신', 
            image: 'images/leesin.png',
            tier: '2티어',
            winRate: '48.22%',
            pickRate: '23.17%',
            banRate: '16.8%',
            summonerSpells: [
                'images/leesinspell.png'
            ],
            items: [
                'images/leesinitem.png'
            ]
        },
        { 
            name: '마스터 이', 
            image: 'images/masteryi.png',
            tier: '3티어',
            winRate: '49.55%',
            pickRate: '3.65%',
            banRate: '2.56%',
            summonerSpells: [
                'images/leesinspell.png'
            ],
            items: [
                'images/masteryiitem.png'
            ]
        },
    ],
    미드: [
        { 
            name: '아리', 
            image: 'images/ahri.png',
            tier: '2티어',
            winRate: '49.83%',
            pickRate: '11.42%',
            banRate: '5.35%',
            summonerSpells: [
                'images/ahrispell.png'
             
            ],
            items: [
                'images/ahriitem.png'
            ]
        },
        { 
            name: '르블랑', 
            image: 'images/leblanc.png',
            tier: '1티어',
            winRate: '50.06%',
            pickRate: '14.23%',
            banRate: '34.93%',
            summonerSpells: [
                'images/ahrispell.png'
            ],
            items: [
                'images/leblancitem.png'
            ]
        }
    ],
    원딜: [
        { 
            name: '카이사', 
            image: 'images/kaisa.png',
            tier: '1티어',
            winRate: '51.52%',
            pickRate: '40%',
            banRate: '9.52%',
            summonerSpells: [
                'images/kaisaspell.png'
            ],
            items: [
                'https://kaisasitem.png'
            ]
        },
        { 
            name: '애쉬', 
            image: 'images/ashe.png',
            tier: '1티어',
            winRate: '51.61%',
            pickRate: '17.09%',
            banRate: '39.73%',
            summonerSpells: [
                'images/ahrispell.png'
            ],
            items: [
                'https://asheitem.png'
            ]
        }
    ],
    서포터: [
        { 
            name: '쓰레쉬', 
            image: 'images/thresh.png',
            tier: '1티어',
            winRate: '50.97%',
            pickRate: '13.64%',
            banRate: '6.68%',
            summonerSpells: [
                'images/threshspell.png'
            ],
            items: [
                'images/threshitem.png'
            ]
        },
        { 
            name: '나미', 
            image: 'images/nami.png',
            tier: '3티어',
            winRate: '50.04%',
            pickRate: '4.25%',
            banRate: '0.7%',
            summonerSpells: [
                'images/namispell.png'
            ],
            items: [
                'images/namiitem.png'
            ]
        }
    ]
};

function showChampionDetail(name, line) {
    const champion = championsData[line].find(champ => champ.name === name);

    if (champion) {
        const championDetailDiv = document.getElementById('champion-detail');
        championDetailDiv.innerHTML = `
            <h1>${champion.name}</h1>
            <img src="${champion.image}" alt="${champion.name}" class="champion-image">
            <p>티어: ${champion.tier}</p>
            <p>승률: ${champion.winRate}</p>
            <p>픽률: ${champion.pickRate}</p>
            <p>밴율: ${champion.banRate}</p>
            <div>
                <h3>소환사 주문</h3>
                <img src="${champion.summonerSpells[0]}" alt="Summoner Spell 1" class="summoner-spell-image" style="width: 100px; height: 50px;">
            </div>
            <div>
                <h3>아이템</h3>
                <img src="${champion.items[0]}" alt="Item 1" class="item-image" style="width: 200px; height: 50px;">
            </div>
        `;
        showChampionDetailPage();
    } else {
        alert('챔피언을 찾을 수 없습니다.');
    }
}


function showMainPage() {
    hideAllPages();
    document.getElementById('main-page').classList.remove('hidden');
}

function showUserSearchPage() {
    hideAllPages();
    document.getElementById('user-search-page').classList.remove('hidden');
}

function showUserInfoPage() {
    hideAllPages();
    document.getElementById('user-info-page').classList.remove('hidden');
}

function showChampionsPage() {
    hideAllPages();
    document.getElementById('champions-page').classList.remove('hidden');
    renderChampionsList();
}

function showChampionDetailPage() {
    hideAllPages();
    document.getElementById('champion-detail-page').classList.remove('hidden');
}

function hideAllPages() {
    document.getElementById('main-page').classList.add('hidden');
    document.getElementById('user-search-page').classList.add('hidden');
    document.getElementById('user-info-page').classList.add('hidden');
    document.getElementById('champions-page').classList.add('hidden');
    document.getElementById('champion-detail-page').classList.add('hidden');
}

function searchUser() {
    const usernameSelect = document.getElementById('username');
    const username = usernameSelect.value;
    const user = userData[username];

    if (user) {
        const userInfoDiv = document.getElementById('user-info');
        userInfoDiv.innerHTML = `
            <h1>${username}의 정보</h1>
            <img src="${user.faceImage}" alt="${username}의 얼굴" class="champion-image">
            <p>레벨: ${user.level}</p>
            <p>랭크: ${user.tier}</p>
            <p>승률: ${user.winRate}</p>
            <img src="${user.tierImage}" alt="${user.tier}" class="tier-image"  style="width: 200px; height: 170px;">
        `;
        showUserInfoPage();
    } else {
        alert('유저를 찾을 수 없습니다.');
    }
}

function renderChampionsList() {
    const championsListDiv = document.getElementById('champions-list');
    championsListDiv.innerHTML = '';

    Object.keys(championsData).forEach(line => {
        const lineDiv = document.createElement('div');
        lineDiv.innerHTML = `<h2>${line.toUpperCase()}</h2>`;

        championsData[line].forEach(champion => {
            const championCard = document.createElement('div');
            championCard.innerHTML = `
                <img src="${champion.image}" alt="${champion.name}">
                <h3 onclick="showChampionDetail('${champion.name}', '${line}')">${champion.name}</h3>
            `;
            lineDiv.appendChild(championCard);
        });

        championsListDiv.appendChild(lineDiv);
    });


}

function goToOfficialWebsite() {
    window.location.href = 'https://www.leagueoflegends.com';
}

